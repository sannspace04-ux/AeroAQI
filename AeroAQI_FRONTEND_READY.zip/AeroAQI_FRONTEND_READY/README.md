# AeroAQI Frontend — Ready-to-run

## Run
1. Open this folder in Kiro / VS Code / terminal.
2. Run: `npm install`
3. Run: `npm run dev`
4. Open the local Vite URL shown in the terminal.

## Included
- Premium dark AeroAQI dashboard
- English / Hindi toggle
- Delhi-NCR interactive map with zoom and AQI color markers
- Red Fort hero image
- Weather + Open-Meteo live widgets
- Forecast, stations, plume, alerts, reports, pipeline
- AI Insights interaction + browser voice playback
- Alert test sound + ambient melody
- Profile/settings with photo, points and gifts UI
- Responsive desktop/mobile navigation

## Important
Forecast/alert/pipeline values that are not yet wired to the exact FastAPI response schema remain clearly treated as demo/prototype values. Do not present them as live government data.
